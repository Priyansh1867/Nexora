function AuthLayout({ children }) {
  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-[#FAFAFA]">

      {/* Left Section */}
      <div className="hidden lg:flex flex-col justify-center px-20 bg-[#1A312C] text-white">

        <h1 className="text-5xl font-bold leading-tight">
          Nexora
        </h1>

        <p className="text-xl mt-4 text-gray-300">
          Student Growth &
          Collaboration Platform
        </p>

        <div className="mt-12">
          <h2 className="text-3xl font-semibold">
            Learn.
          </h2>

          <h2 className="text-3xl font-semibold mt-2">
            Collaborate.
          </h2>

          <h2 className="text-3xl font-semibold mt-2">
            Grow.
          </h2>
        </div>

      </div>

      {/* Right Section */}

      <div className="flex items-center justify-center min-h-screen p-8">

        {children}

      </div>

    </div>
  );
}

export default AuthLayout;