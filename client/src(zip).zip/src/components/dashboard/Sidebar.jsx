import {
  Home,
  User,
  BookOpen,
  Users,
  Bell,
  Settings,
  Trophy,
  UserPlus,
  MoreVertical,
} from "lucide-react";

import SidebarItem from "./SidebarItem";

function Sidebar() {
  return (
    <aside
      className="
        w-[300px]
        h-screen
        bg-[#16332D]
        text-white
        flex
        flex-col
        px-6
        py-7
        shadow-2xl
      "
    >
      {/* Logo */}

      <div className="mb-12 flex items-center gap-4">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#EEF8F4]">
          <span className="text-2xl font-bold text-[#16332D]">
            N
          </span>
        </div>

        <div>
          <h1 className="text-xl font-bold">
            Nexora
          </h1>

          <p className="mt-1 text-xs leading-5 text-gray-300">
            Student Growth &
            <br />
            Collaboration Platform
          </p>
        </div>
      </div>

      {/* Navigation */}

      <nav className="space-y-3">
        <SidebarItem
          to="/"
          title="Home"
          icon={<Home size={19} />}
        />

        <SidebarItem
          to="/profile"
          title="Profile"
          icon={<User size={19} />}
        />

        <SidebarItem
          to="/skill-hub"
          title="SkillHub"
          icon={<BookOpen size={19} />}
        />

        <SidebarItem
          to="/team-finder"
          title="Team Finder"
          icon={<Users size={19} />}
        />

        <SidebarItem
          to="/notifications"
          title="Notifications"
          icon={<Bell size={19} />}
          badge="3"
        />

        <SidebarItem
          to="/settings"
          title="Settings"
          icon={<Settings size={19} />}
        />
      </nav>

      {/* Milestone */}

      <div className="mt-8 rounded-[24px] border border-[#2B4A44] bg-[#1F4039] p-6">
        <div className="flex items-center gap-3">
          <Trophy
            size={18}
            className="text-yellow-400"
          />

          <h3 className="font-semibold">
            Your Next Milestone
          </h3>
        </div>

        <p className="mt-4 text-sm leading-6 text-gray-300">
          Complete 5 skill sessions
        </p>

        <div className="mt-5 h-2 rounded-full bg-[#35554F]">
          <div className="h-full w-3/5 rounded-full bg-[#428475]" />
        </div>

        <div className="mt-4 flex justify-between text-sm">
          <span>3 / 5</span>

          <button className="text-[#8FE5C1] transition hover:underline">
            View →
          </button>
        </div>
      </div>

      {/* Invite */}

      <div className="mt-5 rounded-[24px] border border-[#2B4A44] bg-[#1F4039] p-6">
        <div className="flex items-center gap-3">
          <UserPlus
            size={18}
            className="text-yellow-400"
          />

          <h3 className="font-semibold">
            Invite Friends
          </h3>
        </div>

        <p className="mt-4 text-sm leading-6 text-gray-300">
          Build your network and grow together.
        </p>

        <button className="mt-5 text-[#8FE5C1] transition hover:underline">
          Invite Now →
        </button>
      </div>

      {/* Profile */}

      <div className="mt-auto rounded-[24px] border border-[#2B4A44] bg-[#1F4039] p-5">
        <div className="flex justify-between">
          <div className="flex gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[#428475] font-bold">
              P
            </div>

            <div>
              <h4 className="font-semibold">
                Priyansh Singh
              </h4>

              <p className="text-xs text-gray-300">
                B.Tech AI & DS
              </p>

              <p className="mt-1 text-xs text-green-400">
                ● Available
              </p>
            </div>
          </div>

          <button className="transition hover:text-[#8FE5C1]">
            <MoreVertical size={18} />
          </button>
        </div>

        <div className="mt-5">
          <div className="flex justify-between text-sm">
            <span>Profile</span>

            <span>82%</span>
          </div>

          <div className="mt-2 h-2 rounded-full bg-[#35554F]">
            <div className="h-full w-[82%] rounded-full bg-[#428475]" />
          </div>
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;