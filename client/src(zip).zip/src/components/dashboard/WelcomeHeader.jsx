import { ArrowRight } from "lucide-react";

function WelcomeHeader() {

  const hour = new Date().getHours();

  let greeting = "Good Evening";

  if (hour < 12) {
    greeting = "Good Morning";
  }
  else if (hour < 17) {
    greeting = "Good Afternoon";
  }
  else if (hour >= 20) {
    greeting = "Good Night";
  }

  return (

    <section className="flex justify-between items-center">

      <div>

        <h1 className="text-[58px] font-extrabold leading-none text-[#172033]">

          👋 {greeting}, Priyansh

        </h1>

        <p className="mt-4 text-[22px] text-[#667085]">

          Ready to continue your journey today?

        </p>

      </div>

      <button
        className="
        h-[60px]
        px-8
        rounded-2xl
        bg-[#428475]
        hover:bg-[#1A312C]
        transition-all
        text-white
        font-semibold
        flex
        items-center
        gap-3
        "
      >

        Continue Journey

        <ArrowRight size={20} />

      </button>

    </section>

  );
}

export default WelcomeHeader;