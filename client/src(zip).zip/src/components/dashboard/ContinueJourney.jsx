import { ArrowRight, Clock3 } from "lucide-react";

function ContinueJourney() {
  return (
    <section className="bg-white rounded-[28px] border border-[#EDF1F4] shadow-[0_8px_30px_rgba(0,0,0,0.05)] p-8">

      <div className="flex justify-between items-start mb-10">

        <div>

          <p className="text-[#428475] text-[15px] font-semibold">
            Continue Journey
          </p>

          <h2 className="mt-3 text-[28px] font-bold text-[#172033]">
            Complete your React Fundamentals Path
          </h2>

          <p className="mt-3 max-w-[560px] leading-8 text-[#667085]">
            Continue where you left off and unlock the next milestone in your learning journey.
          </p>

        </div>

        <button className="h-14 px-7 rounded-2xl bg-[#428475] text-white font-semibold flex items-center gap-2 hover:bg-[#1A312C] transition-all">

          Continue

          <ArrowRight size={18} />

        </button>

      </div>

      <div className="flex gap-8 items-center">

        <div className="w-[110px] h-[110px] rounded-[28px] bg-[#10141F] flex items-center justify-center text-[50px]">

          ⚛️

        </div>

        <div className="flex-1">

          <div className="flex justify-between">

            <div>

              <h3 className="text-[32px] font-bold text-[#172033]">
                React.js Roadmap
              </h3>

              <span className="inline-flex mt-3 px-4 py-1 rounded-full bg-[#EEF8F4] text-[#428475] text-sm">
                Intermediate
              </span>

            </div>

            <span className="text-[24px] font-bold text-[#172033]">
              60%
            </span>

          </div>

          <div className="mt-7 h-4 rounded-full bg-[#E8EDF1] overflow-hidden">

            <div className="w-[60%] h-full rounded-full bg-[#428475]" />

          </div>

          <div className="mt-5 flex justify-between">

            <span className="text-[#667085]">
              12 / 20 Lessons Completed
            </span>

            <button className="text-[#428475] font-semibold">
              Continue →
            </button>

          </div>

        </div>

      </div>

      <div className="mt-10 pt-6 border-t border-[#EDF1F4] flex justify-between items-center">

        <div className="flex gap-2 items-center text-[#667085]">

          <Clock3 size={18} />

          <span>25 mins remaining</span>

        </div>

        <span className="text-[#98A2B3]">
          Last opened 2 hours ago
        </span>

      </div>

    </section>
  );
}

export default ContinueJourney;