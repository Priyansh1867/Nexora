import {
  CalendarDays,
  ChevronRight,
  Flame,
  Sparkles,
  Trophy,
  Users,
} from "lucide-react";

const events = [
  {
    title: "Frontend Interview Prep",
    time: "Today • 6:30 PM",
  },
  {
    title: "React 19 Workshop",
    time: "Tomorrow • 11:00 AM",
  },
  {
    title: "Hackathon Team Meeting",
    time: "Friday • 8:00 PM",
  },
];

const communities = [
  "React Developers",
  "AI Builders",
  "Open Source India",
  "UI/UX Community",
];

function RightSidebar() {
  return (
    <aside className="hidden w-[340px] shrink-0 border-l border-[#EDF1F4] bg-white xl:flex xl:flex-col">
      <div className="space-y-7 overflow-y-auto p-6">
        <section className="rounded-[26px] bg-gradient-to-br from-[#16332D] to-[#428475] p-6 text-white">
          <div className="flex items-center gap-3">
            <div className="rounded-2xl bg-white/15 p-3">
              <Flame size={22} />
            </div>

            <div>
              <p className="text-sm opacity-90">
                Current Streak
              </p>

              <h2 className="text-3xl font-bold">
                18 Days
              </h2>
            </div>
          </div>

          <div className="mt-6 h-2 rounded-full bg-white/20">
            <div className="h-full w-[72%] rounded-full bg-white" />
          </div>

          <p className="mt-4 text-sm text-white/90">
            You're ahead of 86% of Nexora learners.
          </p>
        </section>

        <section className="rounded-[26px] border border-[#EDF1F4] p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CalendarDays
                size={18}
                className="text-[#428475]"
              />

              <h3 className="font-semibold text-[#172033]">
                Upcoming Events
              </h3>
            </div>

            <button className="text-[#428475]">
              <ChevronRight size={18} />
            </button>
          </div>

          <div className="mt-6 space-y-4">
            {events.map((event) => (
              <div
                key={event.title}
                className="rounded-2xl bg-[#F8FAFB] p-4"
              >
                <h4 className="font-semibold text-[#172033]">
                  {event.title}
                </h4>

                <p className="mt-1 text-sm text-gray-500">
                  {event.time}
                </p>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-[26px] border border-[#EDF1F4] p-6">
          <div className="flex items-center gap-2">
            <Sparkles
              size={18}
              className="text-[#428475]"
            />

            <h3 className="font-semibold text-[#172033]">
              AI Suggestions
            </h3>
          </div>

          <div className="mt-6 rounded-2xl bg-[#EEF8F4] p-5">
            <p className="font-semibold text-[#16332D]">
              Learn PostgreSQL
            </p>

            <p className="mt-2 text-sm leading-6 text-[#47615C]">
              Based on your current stack, PostgreSQL will improve your backend
              skills and prepare you for production applications.
            </p>

            <button className="mt-5 rounded-xl bg-[#16332D] px-5 py-2 text-sm font-semibold text-white transition hover:bg-[#214740]">
              Start Learning
            </button>
          </div>
        </section>

        <section className="rounded-[26px] border border-[#EDF1F4] p-6">
          <div className="flex items-center gap-2">
            <Users
              size={18}
              className="text-[#428475]"
            />

            <h3 className="font-semibold text-[#172033]">
              Communities
            </h3>
          </div>

          <div className="mt-6 space-y-3">
            {communities.map((community) => (
              <button
                key={community}
                className="flex w-full items-center justify-between rounded-2xl border border-[#EDF1F4] px-4 py-3 transition hover:border-[#428475]"
              >
                <span className="font-medium">
                  {community}
                </span>

                <ChevronRight size={18} />
              </button>
            ))}
          </div>
        </section>

        <section className="rounded-[26px] border border-[#EDF1F4] bg-[#FFF9EC] p-6">
          <div className="flex items-center gap-2">
            <Trophy
              size={20}
              className="text-yellow-500"
            />

            <h3 className="font-semibold">
              Weekly Goal
            </h3>
          </div>

          <p className="mt-4 text-sm leading-6 text-gray-600">
            Finish 3 learning modules and contribute to one project this week.
          </p>

          <div className="mt-5 h-2 rounded-full bg-yellow-100">
            <div className="h-full w-[68%] rounded-full bg-yellow-500" />
          </div>

          <div className="mt-3 flex justify-between text-sm font-medium">
            <span>68%</span>
            <span>3 / 5</span>
          </div>
        </section>
      </div>
    </aside>
  );
}

export default RightSidebar;