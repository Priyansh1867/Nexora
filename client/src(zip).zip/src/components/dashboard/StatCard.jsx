function StatCard({
  title,
  value,
  subtitle,
  icon,
}) {
  return (
    <div
      className="
      h-[180px]
      bg-white
      rounded-[28px]
      border
      border-[#EDF1F4]
      shadow-[0_8px_30px_rgba(0,0,0,0.05)]
      p-7
      flex
      flex-col
      justify-between
      hover:-translate-y-1
      hover:shadow-[0_16px_35px_rgba(0,0,0,0.08)]
      transition-all
      duration-300
      "
    >
      <div className="flex justify-between">

        <div>

          <p className="text-[14px] font-medium text-[#667085]">
            {title}
          </p>

          <h2 className="mt-3 text-[46px] font-bold leading-none text-[#172033]">
            {value}
          </h2>

          <p className="mt-3 text-[#428475] text-[15px]">
            {subtitle}
          </p>

        </div>

        <div
          className="
          w-[72px]
          h-[72px]
          rounded-[22px]
          bg-[#EEF8F4]
          flex
          items-center
          justify-center
          text-[#428475]
          "
        >
          {icon}
        </div>

      </div>

      <div className="flex justify-between items-center">

        <span className="text-[#98A2B3] text-[15px]">
          View Details
        </span>

        <span className="text-[#428475] text-xl">
          →
        </span>

      </div>

    </div>
  );
}

export default StatCard;