import {
  BookOpen,
  Clock3,
  PlayCircle,
  ArrowRight,
  CheckCircle2,
} from "lucide-react";

const libraryItems = [
  {
    id: 1,
    title: "React 19 Complete Guide",
    category: "Frontend",
    progress: 78,
    duration: "12h 20m",
    lessons: "42 Lessons",
    color: "from-sky-500 to-cyan-500",
  },
  {
    id: 2,
    title: "Node.js & Express Masterclass",
    category: "Backend",
    progress: 46,
    duration: "18h 10m",
    lessons: "61 Lessons",
    color: "from-green-500 to-emerald-500",
  },
  {
    id: 3,
    title: "PostgreSQL for Developers",
    category: "Database",
    progress: 91,
    duration: "9h 35m",
    lessons: "28 Lessons",
    color: "from-indigo-500 to-violet-500",
  },
];

function LibraryCard() {
  return (
    <section className="rounded-[28px] border border-[#EDF1F4] bg-white p-8 shadow-[0_8px_30px_rgba(0,0,0,0.05)]">
      <div className="flex items-center justify-between">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full bg-[#EEF8F4] px-4 py-2 text-sm font-semibold text-[#428475]">
            <BookOpen size={16} />
            Learning Library
          </div>

          <h2 className="mt-4 text-3xl font-bold text-[#172033]">
            Continue where you left off
          </h2>

          <p className="mt-3 max-w-2xl text-[15px] leading-7 text-[#667085]">
            Track your active courses, monitor your progress and keep learning
            every day.
          </p>
        </div>

        <button className="flex items-center gap-2 rounded-2xl border border-[#E5E7EB] px-5 py-3 text-sm font-semibold text-[#172033] transition hover:border-[#428475] hover:text-[#428475]">
          View Library
          <ArrowRight size={16} />
        </button>
      </div>

      <div className="mt-10 grid gap-6 lg:grid-cols-3">
        {libraryItems.map((course) => (
          <div
            key={course.id}
            className="overflow-hidden rounded-[26px] border border-[#EEF2F5] transition-all duration-300 hover:-translate-y-1 hover:border-[#428475] hover:shadow-xl"
          >
            <div
              className={`h-40 bg-gradient-to-br ${course.color} flex items-center justify-center`}
            >
              <PlayCircle
                size={58}
                className="text-white"
                strokeWidth={1.6}
              />
            </div>

            <div className="p-6">
              <span className="rounded-full bg-[#EEF8F4] px-3 py-1 text-xs font-semibold text-[#428475]">
                {course.category}
              </span>

              <h3 className="mt-4 text-xl font-bold leading-8 text-[#172033]">
                {course.title}
              </h3>

              <div className="mt-6 flex items-center justify-between text-sm text-[#667085]">
                <div className="flex items-center gap-2">
                  <Clock3 size={16} />
                  {course.duration}
                </div>

                <div>{course.lessons}</div>
              </div>

              <div className="mt-6">
                <div className="mb-2 flex items-center justify-between text-sm">
                  <span className="font-medium text-[#172033]">
                    Progress
                  </span>

                  <span className="font-semibold text-[#428475]">
                    {course.progress}%
                  </span>
                </div>

                <div className="h-2 overflow-hidden rounded-full bg-[#EDF1F4]">
                  <div
                    className="h-full rounded-full bg-[#428475] transition-all"
                    style={{
                      width: `${course.progress}%`,
                    }}
                  />
                </div>
              </div>

              <button className="mt-7 flex w-full items-center justify-center gap-2 rounded-2xl bg-[#16332D] px-5 py-3 font-semibold text-white transition hover:bg-[#214740]">
                {course.progress === 100 ? (
                  <>
                    <CheckCircle2 size={18} />
                    Completed
                  </>
                ) : (
                  <>
                    <PlayCircle size={18} />
                    Continue Learning
                  </>
                )}
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default LibraryCard;