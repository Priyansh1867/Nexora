import { NavLink } from "react-router-dom";

function SidebarItem({
  to,
  icon,
  title,
  badge,
}) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `flex items-center justify-between rounded-2xl px-4 py-3.5 transition-all duration-300 ${
          isActive
            ? "bg-[#428475] text-white shadow-lg"
            : "text-gray-200 hover:bg-[#22433D] hover:text-white"
        }`
      }
    >
      {({ isActive }) => (
        <>
          <div className="flex items-center gap-4">

            <div
              className={`transition ${
                isActive ? "scale-110" : ""
              }`}
            >
              {icon}
            </div>

            <span className="text-[15px] font-medium">
              {title}
            </span>

          </div>

          {badge && (
            <div className="w-6 h-6 rounded-full bg-[#4FA387] text-white text-[11px] font-semibold flex items-center justify-center">

              {badge}

            </div>
          )}
        </>
      )}
    </NavLink>
  );
}

export default SidebarItem;