import { Sparkles, Circle } from "lucide-react";

function ProfileCompletion() {
  return (
    <section className="bg-white rounded-[28px] border border-[#EDF1F4] shadow-[0_8px_30px_rgba(0,0,0,0.05)] p-7">

      <div className="flex items-center gap-3">

        <div className="w-12 h-12 rounded-2xl bg-[#EEF8F4] flex items-center justify-center">

          <Sparkles
            size={22}
            className="text-[#428475]"
          />

        </div>

        <div>

          <h2 className="font-bold text-[#172033]">
            Profile Strength
          </h2>

          <p className="text-sm text-[#667085]">
            Almost Ready 🚀
          </p>

        </div>

      </div>

      <div className="flex justify-center my-8">

        <div className="relative w-[170px] h-[170px] rounded-full border-[12px] border-[#E8EDF1] flex items-center justify-center">

          <div className="absolute inset-0 rounded-full border-[12px] border-[#428475] border-r-transparent border-b-transparent rotate-45"></div>

          <div className="text-center">

            <h1 className="text-5xl font-bold text-[#172033]">
              82%
            </h1>

            <p className="text-sm text-[#667085] mt-2">
              Completed
            </p>

          </div>

        </div>

      </div>

      <div className="border-t border-[#EDF1F4] pt-6">

        <h3 className="font-semibold text-[#172033] mb-5">
          Remaining Tasks
        </h3>

        <div className="space-y-4">

          <Task title="Upload Resume" />
          <Task title="Add GitHub Profile" />
          <Task title="Complete Bio" />

        </div>

      </div>

      <button className="mt-8 w-full h-12 rounded-2xl bg-[#428475] hover:bg-[#1A312C] text-white font-semibold transition-all">

        Complete Profile

      </button>

    </section>
  );
}

function Task({ title }) {
  return (
    <div className="flex items-center gap-3">

      <Circle
        size={18}
        className="text-[#98A2B3]"
      />

      <span className="text-[#667085]">
        {title}
      </span>

    </div>
  );
}

export default ProfileCompletion;