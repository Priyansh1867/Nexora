import {
  ArrowRight,
  Clock3,
  Users,
  Star,
  UserPlus,
  BriefcaseBusiness,
} from "lucide-react";

const invitations = [
  {
    id: 1,
    team: "AI Innovators",
    role: "Frontend Developer",
    members: 6,
    rating: 4.9,
    deadline: "2 Days Left",
    color: "bg-blue-100 text-blue-700",
  },
  {
    id: 2,
    team: "HackVerse",
    role: "Backend Developer",
    members: 5,
    rating: 4.8,
    deadline: "5 Days Left",
    color: "bg-green-100 text-green-700",
  },
  {
    id: 3,
    team: "CodeStorm",
    role: "UI/UX Designer",
    members: 4,
    rating: 4.7,
    deadline: "1 Week Left",
    color: "bg-orange-100 text-orange-700",
  },
];

function TeamInvitation() {
  return (
    <section className="rounded-[28px] border border-[#EDF1F4] bg-white p-8 shadow-[0_8px_30px_rgba(0,0,0,0.05)]">
      <div className="flex items-center justify-between">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full bg-[#EEF8F4] px-4 py-2 text-sm font-semibold text-[#428475]">
            <Users size={16} />
            Team Invitations
          </div>

          <h2 className="mt-4 text-3xl font-bold text-[#172033]">
            Teams looking for collaborators
          </h2>

          <p className="mt-3 max-w-2xl text-[15px] leading-7 text-[#667085]">
            Join active student teams, contribute to real projects and build an
            impressive portfolio together.
          </p>
        </div>

        <button className="flex items-center gap-2 rounded-2xl border border-[#E5E7EB] px-5 py-3 text-sm font-semibold text-[#172033] transition hover:border-[#428475] hover:text-[#428475]">
          Explore Teams
          <ArrowRight size={16} />
        </button>
      </div>

      <div className="mt-10 space-y-6">
        {invitations.map((team) => (
          <div
            key={team.id}
            className="flex flex-col gap-6 rounded-[26px] border border-[#EEF2F5] p-6 transition-all duration-300 hover:-translate-y-1 hover:border-[#428475] hover:shadow-xl lg:flex-row lg:items-center lg:justify-between"
          >
            <div className="flex items-center gap-5">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[#EEF8F4] text-[#428475]">
                <BriefcaseBusiness size={28} />
              </div>

              <div>
                <h3 className="text-xl font-bold text-[#172033]">
                  {team.team}
                </h3>

                <p className="mt-1 text-[#667085]">
                  Required Role:{" "}
                  <span className="font-semibold">{team.role}</span>
                </p>

                <div className="mt-4 flex flex-wrap gap-4 text-sm text-[#667085]">
                  <div className="flex items-center gap-2">
                    <Users size={16} />
                    {team.members} Members
                  </div>

                  <div className="flex items-center gap-2">
                    <Star
                      size={16}
                      className="fill-yellow-400 text-yellow-400"
                    />
                    {team.rating}
                  </div>

                  <div className="flex items-center gap-2">
                    <Clock3 size={16} />
                    {team.deadline}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <span
                className={`rounded-full px-4 py-2 text-sm font-semibold ${team.color}`}
              >
                {team.role}
              </span>

              <button className="flex items-center gap-2 rounded-2xl bg-[#16332D] px-6 py-3 font-semibold text-white transition hover:bg-[#214740]">
                <UserPlus size={18} />
                Join Team
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default TeamInvitation;