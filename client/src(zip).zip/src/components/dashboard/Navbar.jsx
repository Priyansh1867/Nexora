import {
  Search,
  Bell,
 MessageCircle,
  Sun,
  ChevronDown,
} from "lucide-react";

function Navbar() {
  return (
    <header className="h-24 bg-white border-b border-[#EDF1F4] flex items-center justify-between px-8">

      <div className="w-[560px] relative">

        <Search
          size={18}
          className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400"
        />

        <input
          type="text"
          placeholder="Search builders, skills, projects..."
          className="w-full h-14 rounded-2xl border border-[#E6EBEF] pl-14 pr-20 outline-none"
        />

        <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">
          ⌘ K
        </div>

      </div>

      <div className="flex items-center gap-5">

        <button className="w-14 h-14 rounded-2xl bg-[#F8FAFB] flex items-center justify-center">
          <Sun size={20} />
        </button>

        <button className="w-14 h-14 rounded-2xl bg-[#F8FAFB] flex items-center justify-center relative">
          <Bell size={20} />
          <span className="absolute top-2 right-2 w-5 h-5 rounded-full bg-red-500 text-white text-[10px] flex items-center justify-center">
            3
          </span>
        </button>

        <button className="w-14 h-14 rounded-2xl bg-[#F8FAFB] flex items-center justify-center">
          <MessageCircle size={20} />
        </button>

        <div className="flex items-center gap-4 ml-2">

          <div className="w-14 h-14 rounded-full bg-[#428475] text-white flex items-center justify-center font-bold">
            P
          </div>

          <div>

            <h4 className="font-semibold">
              Priyansh Singh
            </h4>

            <p className="text-sm text-gray-500">
              Student
            </p>

          </div>

          <ChevronDown size={18} />

        </div>

      </div>

    </header>
  );
}

export default Navbar;