import {
  Calendar,
  GraduationCap,
  Mail,
  MapPin,
  Phone,
} from "lucide-react";

function ProfileCard({ profile }) {
  return (
    <section className="rounded-[30px] border border-[#EDF1F4] bg-white p-8 shadow-sm">
      <div className="flex flex-col items-center text-center">
        <div className="flex h-32 w-32 items-center justify-center rounded-full bg-[#428475] text-5xl font-bold text-white">
          {profile.name.charAt(0)}
        </div>

        <h2 className="mt-6 text-3xl font-bold text-[#172033]">
          {profile.name}
        </h2>

        <p className="mt-2 text-[#428475]">
          {profile.role}
        </p>

        <div className="mt-8 w-full space-y-5">
          <Info
            icon={<Mail size={18} />}
            value={profile.email}
          />

          <Info
            icon={<Phone size={18} />}
            value={profile.phone}
          />

          <Info
            icon={<MapPin size={18} />}
            value={profile.location}
          />

          <Info
            icon={<GraduationCap size={18} />}
            value={profile.college}
          />

          <Info
            icon={<Calendar size={18} />}
            value="Final Year"
          />
        </div>
      </div>
    </section>
  );
}

function Info({
  icon,
  value,
}) {
  return (
    <div className="flex items-center gap-3 rounded-2xl bg-[#F8FAFB] p-4">
      <div className="text-[#428475]">
        {icon}
      </div>

      <span className="text-sm text-gray-700">
        {value}
      </span>
    </div>
  );
}

export default ProfileCard;