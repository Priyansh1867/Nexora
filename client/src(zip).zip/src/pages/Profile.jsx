import { useState } from "react";

import DashboardLayout from "../layouts/DashboardLayout";

import ProfileCard from "../components/ProfileCard";
import SkillCard from "../components/SkillCard";

import {
  Pencil,
  Save,
  X,
  Upload,
  Github,
  Linkedin,
  Globe,
  GraduationCap,
  Briefcase,
  Award,
  FileText,
} from "lucide-react";

function Profile() {
  const [editing, setEditing] = useState(false);

  const [profile, setProfile] = useState({
    name: "Priyansh Singh",
    role: "Full Stack Developer",

    college: "JECRC University",

    location: "Jaipur, Rajasthan",

    email: "priyansh@example.com",

    phone: "+91 9876543210",

    github: "https://github.com/Priyansh1867",

    linkedin: "https://linkedin.com/in/priyansh",

    portfolio: "https://nexora.dev",

    bio:
      "Passionate Full Stack Developer interested in React, Node.js, PostgreSQL, scalable web applications and AI powered products.",
  });

  const [skills] = useState([
    {
      skill: "React",
      level: "Advanced",
      progress: 90,
    },
    {
      skill: "JavaScript",
      level: "Advanced",
      progress: 92,
    },
    {
      skill: "Node.js",
      level: "Intermediate",
      progress: 75,
    },
    {
      skill: "Express.js",
      level: "Intermediate",
      progress: 72,
    },
    {
      skill: "PostgreSQL",
      level: "Intermediate",
      progress: 68,
    },
    {
      skill: "MongoDB",
      level: "Intermediate",
      progress: 82,
    },
    {
      skill: "Tailwind CSS",
      level: "Advanced",
      progress: 94,
    },
    {
      skill: "Git",
      level: "Advanced",
      progress: 87,
    },
  ]);

  const handleChange = (e) => {
    setProfile((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <section className="rounded-[30px] bg-gradient-to-r from-[#16332D] to-[#428475] p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold">
                My Profile
              </h1>

              <p className="mt-3 text-white/80">
                Manage your personal profile,
                skills and professional journey.
              </p>
            </div>

            <div className="flex gap-3">
              {editing && (
                <button className="flex items-center gap-2 rounded-xl bg-white px-6 py-3 font-semibold text-[#16332D] transition hover:scale-105">
                  <Save size={18} />
                  Save
                </button>
              )}

              <button
                onClick={() =>
                  setEditing(!editing)
                }
                className="flex items-center gap-2 rounded-xl border border-white/30 bg-white/10 px-6 py-3 font-semibold backdrop-blur transition hover:bg-white hover:text-[#16332D]"
              >
                {editing ? (
                  <>
                    <X size={18} />
                    Cancel
                  </>
                ) : (
                  <>
                    <Pencil size={18} />
                    Edit Profile
                  </>
                )}
              </button>
            </div>
          </div>
        </section>

        <div className="grid gap-8 xl:grid-cols-[360px_1fr]">
          <ProfileCard profile={profile} />

          <div className="space-y-8">
            <section className="rounded-[30px] border border-[#EDF1F4] bg-white p-8">
              <h2 className="mb-8 text-2xl font-bold text-[#172033]">
                Personal Information
              </h2>

              <div className="grid gap-6 md:grid-cols-2">
                <Field
                  editing={editing}
                  label="Full Name"
                  name="name"
                  value={profile.name}
                  onChange={handleChange}
                />

                <Field
                  editing={editing}
                  label="Role"
                  name="role"
                  value={profile.role}
                  onChange={handleChange}
                />

                <Field
                  editing={editing}
                  label="College"
                  name="college"
                  value={profile.college}
                  onChange={handleChange}
                />

                <Field
                  editing={editing}
                  label="Location"
                  name="location"
                  value={profile.location}
                  onChange={handleChange}
                />

                <Field
                  editing={editing}
                  label="Email"
                  name="email"
                  value={profile.email}
                  onChange={handleChange}
                />

                <Field
                  editing={editing}
                  label="Phone"
                  name="phone"
                  value={profile.phone}
                  onChange={handleChange}
                />
              </div>

              <div className="mt-8">
                <label className="mb-3 block font-semibold">
                  About Me
                </label>

                {editing ? (
                  <textarea
                    rows={6}
                    name="bio"
                    value={profile.bio}
                    onChange={handleChange}
                    className="w-full rounded-2xl border border-[#E5E7EB] p-4 outline-none focus:border-[#428475]"
                  />
                ) : (
                  <p className="leading-8 text-gray-600">
                    {profile.bio}
                  </p>
                )}
              </div>
            </section>

            <section className="rounded-[30px] border border-[#EDF1F4] bg-white p-8">
              <div className="mb-8 flex items-center gap-3">
                <Award className="text-[#428475]" />

                <h2 className="text-2xl font-bold">
                  Technical Skills
                </h2>
              </div>

              <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
                {skills.map((skill) => (
                  <SkillCard
                    key={skill.skill}
                    skill={skill.skill}
                    level={skill.level}
                    progress={skill.progress}
                  />
                ))}
              </div>
            </section>
        import { useState } from "react";

import DashboardLayout from "../layouts/DashboardLayout";

import ProfileCard from "../components/ProfileCard";
import SkillCard from "../components/SkillCard";

import {
  Pencil,
  Save,
  X,
  Upload,
  Github,
  Linkedin,
  Globe,
  GraduationCap,
  Briefcase,
  Award,
  FileText,
} from "lucide-react";

function Profile() {
  const [editing, setEditing] = useState(false);

  const [profile, setProfile] = useState({
    name: "Priyansh Jain",
    role: "Full Stack Developer",

    college: "JECRC University",

    location: "Jaipur, Rajasthan",

    email: "priyansh@example.com",

    phone: "+91 9876543210",

    github: "https://github.com/Priyansh1867",

    linkedin: "https://linkedin.com/in/priyansh",

    portfolio: "https://nexora.dev",

    bio:
      "Passionate Full Stack Developer interested in React, Node.js, PostgreSQL, scalable web applications and AI powered products.",
  });

  const [skills] = useState([
    {
      skill: "React",
      level: "Advanced",
      progress: 90,
    },
    {
      skill: "JavaScript",
      level: "Advanced",
      progress: 92,
    },
    {
      skill: "Node.js",
      level: "Intermediate",
      progress: 75,
    },
    {
      skill: "Express.js",
      level: "Intermediate",
      progress: 72,
    },
    {
      skill: "PostgreSQL",
      level: "Intermediate",
      progress: 68,
    },
    {
      skill: "MongoDB",
      level: "Intermediate",
      progress: 82,
    },
    {
      skill: "Tailwind CSS",
      level: "Advanced",
      progress: 94,
    },
    {
      skill: "Git",
      level: "Advanced",
      progress: 87,
    },
  ]);

  const handleChange = (e) => {
    setProfile((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <section className="rounded-[30px] bg-gradient-to-r from-[#16332D] to-[#428475] p-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold">
                My Profile
              </h1>

              <p className="mt-3 text-white/80">
                Manage your personal profile,
                skills and professional journey.
              </p>
            </div>

            <div className="flex gap-3">
              {editing && (
                <button className="flex items-center gap-2 rounded-xl bg-white px-6 py-3 font-semibold text-[#16332D] transition hover:scale-105">
                  <Save size={18} />
                  Save
                </button>
              )}

              <button
                onClick={() =>
                  setEditing(!editing)
                }
                className="flex items-center gap-2 rounded-xl border border-white/30 bg-white/10 px-6 py-3 font-semibold backdrop-blur transition hover:bg-white hover:text-[#16332D]"
              >
                {editing ? (
                  <>
                    <X size={18} />
                    Cancel
                  </>
                ) : (
                  <>
                    <Pencil size={18} />
                    Edit Profile
                  </>
                )}
              </button>
            </div>
          </div>
        </section>

        <div className="grid gap-8 xl:grid-cols-[360px_1fr]">
          <ProfileCard profile={profile} />

          <div className="space-y-8">
            <section className="rounded-[30px] border border-[#EDF1F4] bg-white p-8">
              <h2 className="mb-8 text-2xl font-bold text-[#172033]">
                Personal Information
              </h2>

              <div className="grid gap-6 md:grid-cols-2">
                <Field
                  editing={editing}
                  label="Full Name"
                  name="name"
                  value={profile.name}
                  onChange={handleChange}
                />

                <Field
                  editing={editing}
                  label="Role"
                  name="role"
                  value={profile.role}
                  onChange={handleChange}
                />

                <Field
                  editing={editing}
                  label="College"
                  name="college"
                  value={profile.college}
                  onChange={handleChange}
                />

                <Field
                  editing={editing}
                  label="Location"
                  name="location"
                  value={profile.location}
                  onChange={handleChange}
                />

                <Field
                  editing={editing}
                  label="Email"
                  name="email"
                  value={profile.email}
                  onChange={handleChange}
                />

                <Field
                  editing={editing}
                  label="Phone"
                  name="phone"
                  value={profile.phone}
                  onChange={handleChange}
                />
              </div>

              <div className="mt-8">
                <label className="mb-3 block font-semibold">
                  About Me
                </label>

                {editing ? (
                  <textarea
                    rows={6}
                    name="bio"
                    value={profile.bio}
                    onChange={handleChange}
                    className="w-full rounded-2xl border border-[#E5E7EB] p-4 outline-none focus:border-[#428475]"
                  />
                ) : (
                  <p className="leading-8 text-gray-600">
                    {profile.bio}
                  </p>
                )}
              </div>
            </section>

            <section className="rounded-[30px] border border-[#EDF1F4] bg-white p-8">
              <div className="mb-8 flex items-center gap-3">
                <Award className="text-[#428475]" />

                <h2 className="text-2xl font-bold">
                  Technical Skills
                </h2>
              </div>

              <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
                {skills.map((skill) => (
                  <SkillCard
                    key={skill.skill}
                    skill={skill.skill}
                    level={skill.level}
                    progress={skill.progress}
                  />
                ))}
              </div>
            </section>    