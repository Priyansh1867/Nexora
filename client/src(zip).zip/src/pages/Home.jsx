import DashboardLayout from "../layouts/DashboardLayout";

import WelcomeHeader from "../components/dashboard/WelcomeHeader";
import QuickActions from "../components/dashboard/QuickActions";
import StatCard from "../components/dashboard/StatCard";
import ContinueJourney from "../components/dashboard/ContinueJourney";
import TrendingSkills from "../components/dashboard/TrendingSkills";
import TeamInvitation from "../components/dashboard/TeamInvitation";
import LibraryCard from "../components/dashboard/LibraryCard";
import ActivityTimeline from "../components/dashboard/ActivityTimeline";
import ProfileCompletion from "../components/dashboard/ProfileCompletion";
import RightSidebar from "../components/dashboard/RightSidebar";

import {
  BookOpen,
  FolderKanban,
  Trophy,
  Users,
} from "lucide-react";

const stats = [
  {
    title: "Skills Completed",
    value: "18",
    subtitle: "+3 this week",
    icon: <BookOpen size={24} />,
  },
  {
    title: "Projects",
    value: "07",
    subtitle: "2 Active",
    icon: <FolderKanban size={24} />,
  },
  {
    title: "Achievements",
    value: "14",
    subtitle: "Gold Level",
    icon: <Trophy size={24} />,
  },
  {
    title: "Connections",
    value: "126",
    subtitle: "+12 this month",
    icon: <Users size={24} />,
  },
];

function Home() {
  return (
    <DashboardLayout>
      <div className="flex gap-8">
        <div className="min-w-0 flex-1 space-y-8">
          <WelcomeHeader />

          <section className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
            {stats.map((item) => (
              <StatCard
                key={item.title}
                title={item.title}
                value={item.value}
                subtitle={item.subtitle}
                icon={item.icon}
              />
            ))}
          </section>

          <QuickActions />

          <div className="grid gap-8 xl:grid-cols-[1.6fr_1fr]">
            <ContinueJourney />
            <ProfileCompletion />
          </div>

          <TrendingSkills />

          <LibraryCard />

          <TeamInvitation />

          <ActivityTimeline />
        </div>

        <RightSidebar />
      </div>
    </DashboardLayout>
  );
}

export default Home;